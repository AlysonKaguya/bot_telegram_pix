# Bot Telegram de Vendas com Acesso Automático via Pix

## Funcionalidades
- Oferece planos semanal (R$5) e mensal (R$12)
- Gera cobrança Pix pela Gerencianet
- Libera acesso a grupo no Telegram automaticamente após pagamento
- Remove usuário ao fim do período contratado

## Como usar
1. Instale dependências:
```bash
pip install -r requirements.txt
```

2. Crie o arquivo `.env` com suas credenciais:
```
BOT_TOKEN=seu_token_aqui
GRUPO_ID=-1001234567890
PIX_KEY=sua_chave_pix
CLIENT_ID=xxxxxxxxxxxxxx
CLIENT_SECRET=xxxxxxxxxxxxxxxx
```

3. Coloque os arquivos `cert.pem` e `key.pem` na pasta `certs/`

4. Execute o bot:
```bash
python bot.py
```

## Subir no Railway
- Suba esse projeto
- Configure variáveis de ambiente
- Webhook: `/webhook` (registre na Gerencianet)

Feito com ❤️ por ChatGPT
