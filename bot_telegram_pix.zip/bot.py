
<conteúdo do bot.py será inserido aqui>
